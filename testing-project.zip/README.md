# testingProject

A Project to test my node skill

This is a work in progress - will write more when there is more to write :-)
